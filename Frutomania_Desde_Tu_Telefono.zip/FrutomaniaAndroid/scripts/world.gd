extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const ControlsScript = preload("res://scripts/mobile_controls.gd")
var player: CharacterBody3D
var hud: CanvasLayer
var status_label: Label
var mission_label: Label
var mission_index := 0
var coins := 0
var character_index := 0
var characters := ["Fresa", "Piña", "Guayaba"]
var mission_texts := ["MISIÓN 1: Encuentra 3 monedas por el barrio.", "MISIÓN 2: Habla con Piña en la plaza.", "¡MISIÓN COMPLETADA! Explora Frutomanía."]
var mission_done := false
var interactables: Array[Node3D] = []
var message_timer := 0.0

func _ready() -> void:
	_make_environment()
	_make_town()
	_make_houses()
	_make_cars()
	_make_player()
	_make_characters()
	_make_coins()
	_make_hud()
	_update_hud()

func _make_environment() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	e.sky = Sky.new()
	e.sky.sky_material = ProceduralSkyMaterial.new()
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.72, 0.78, 0.9)
	e.ambient_light_energy = 0.8
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -30, 0)
	sun.light_energy = 1.25
	add_child(sun)
	var ground := _box("Green ground", Vector3(0, -0.5, 0), Vector3(120, 1, 120), Color("79b95b"))
	add_child(ground)
	# Plaza and roads
	add_child(_box("Main avenue", Vector3(0, 0.02, 0), Vector3(12, 0.08, 100), Color("454b55")))
	add_child(_box("Cross street", Vector3(0, 0.04, 0), Vector3(100, 0.1, 12), Color("454b55")))
	for i in range(-4, 5):
		add_child(_box("Road dash", Vector3(0, 0.09, i * 10), Vector3(0.22, 0.03, 4), Color("f6e7a0")))
		add_child(_box("Road dash", Vector3(i * 10, 0.1, 0), Vector3(4, 0.03, 0.22), Color("f6e7a0")))

func _make_town() -> void:
	var palette := [Color("ffb36b"), Color("79c7d9"), Color("f2d06b"), Color("d99ac7"), Color("a5d6a7"), Color("c4b5fd")]
	var spots := [Vector3(-17,0,-16), Vector3(17,0,-17), Vector3(-18,0,17), Vector3(18,0,18), Vector3(-31,0,-5), Vector3(31,0,6), Vector3(-8,0,30), Vector3(8,0,-31), Vector3(-32,0,27), Vector3(32,0,-27)]
	for i in range(spots.size()):
		var p: Vector3 = spots[i]
		var h := 5.0 + float(i % 3) * 1.6
		var building := _box("Fruit town building", p + Vector3(0,h/2,0), Vector3(8,h,7), palette[i % palette.size()])
		add_child(building)
		var roof := _box("Roof", p + Vector3(0,h+0.15,0), Vector3(8.4,0.3,7.4), Color("594c68"))
		add_child(roof)
		for x in [-2.2, 2.2]:
			for y in [1.7, 3.5]:
				if y < h - 0.3:
					var win := _box("Window", p + Vector3(x,y,3.54), Vector3(1.15,1.1,0.08), Color("b9ecff"))
					add_child(win)
	# park trees around the edges
	for i in range(26):
		var x := float((i * 17) % 92) - 46.0
		var z := float((i * 29) % 92) - 46.0
		if abs(x) < 9 or abs(z) < 9: continue
		var trunk := _cylinder("Tree trunk", Vector3(x,1.0,z), 0.35, 2.0, Color("8c5a35"))
		add_child(trunk)
		var crown := _sphere("Tree crown", Vector3(x,2.5,z), Vector3(1.4,1.6,1.4), Color("3b9b5b"))
		add_child(crown)
	# mission plaza
	add_child(_cylinder("Plaza fountain base", Vector3(0,0.15,-8), 2.4, 0.3, Color("9cc6d8")))
	add_child(_cylinder("Fountain water", Vector3(0,0.36,-8), 1.7, 0.12, Color("55c9e8")))

func _make_houses() -> void:
	# Exterior house with a clearly marked door.
	var house_pos := Vector3(24, 0, 22)
	add_child(_box("Casa de Frutomania", house_pos + Vector3(0, 2.2, 0), Vector3(9, 4.4, 7), Color("f3c987")))
	add_child(_box("Casa roof", house_pos + Vector3(0, 4.55, 0), Vector3(9.6, 0.35, 7.6), Color("b84e4e")))
	add_child(_box("Casa door frame", house_pos + Vector3(0, 1.1, -3.56), Vector3(1.5, 2.2, 0.18), Color("6d412a")))
	var door := _box("Puerta de casa", house_pos + Vector3(0, 1.05, -3.68), Vector3(1.15, 2.0, 0.12), Color("d6a45e"))
	door.set_meta("house_enter", true)
	add_child(door)
	interactables.append(door)
	# Interior placed in a separate coordinate pocket, reached through the door.
	var inside := Vector3(220, 0, 220)
	add_child(_box("Interior floor", inside + Vector3(0, -0.1, 0), Vector3(12, 0.2, 10), Color("d8c5a4")))
	add_child(_box("Interior back wall", inside + Vector3(0, 2, -5), Vector3(12, 4, 0.25), Color("f5e9d4")))
	add_child(_box("Interior left wall", inside + Vector3(-6, 2, 0), Vector3(0.25, 4, 10), Color("e9d8bd")))
	add_child(_box("Interior right wall", inside + Vector3(6, 2, 0), Vector3(0.25, 4, 10), Color("e9d8bd")))
	add_child(_box("Interior front wall", inside + Vector3(0, 2, 5), Vector3(12, 4, 0.25), Color("f5e9d4")))
	add_child(_box("Living room rug", inside + Vector3(0, 0.03, 0.6), Vector3(4.2, 0.06, 3.0), Color("b65f5f")))
	add_child(_box("Sofa", inside + Vector3(0, 0.55, -2.7), Vector3(3.3, 1.0, 0.9), Color("4f91a6")))
	add_child(_box("Coffee table", inside + Vector3(0, 0.55, 0.2), Vector3(2.0, 0.15, 1.0), Color("805537")))
	var exit_door := _box("Puerta de salida", inside + Vector3(0, 1.0, 4.75), Vector3(1.5, 2.0, 0.15), Color("d6a45e"))
	exit_door.set_meta("house_exit", true)
	add_child(exit_door)
	interactables.append(exit_door)
	var sign := Label3D.new()
	sign.text = "CASA FRUTOMANÍA\nAcércate y pulsa ACCIÓN"
	sign.position = house_pos + Vector3(0, 3.3, -4.0)
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.font_size = 28
	add_child(sign)

func _make_cars() -> void:
	var car_specs := [
		{"pos": Vector3(8, 0.15, 18), "color": Color("e74c3c"), "name": "Fruta-móvil rojo"},
		{"pos": Vector3(-8, 0.15, -18), "color": Color("3498db"), "name": "Fruta-móvil azul"}
	]
	for spec in car_specs:
		var car := Node3D.new()
		car.name = spec.name
		car.position = spec.pos
		car.set_meta("drivable_car", true)
		car.add_child(_box("Car body", Vector3(0, 0.65, 0), Vector3(2.0, 0.75, 3.4), spec.color))
		car.add_child(_box("Car cabin", Vector3(0, 1.25, -0.15), Vector3(1.55, 0.65, 1.65), Color("bde7f2")))
		car.add_child(_box("Front bumper", Vector3(0, 0.42, -1.78), Vector3(1.9, 0.2, 0.18), Color("dedede")))
		car.add_child(_box("Rear bumper", Vector3(0, 0.42, 1.78), Vector3(1.9, 0.2, 0.18), Color("dedede")))
		for x in [-1.0, 1.0]:
			for z in [-1.1, 1.1]:
				var wheel := _cylinder("Wheel", Vector3(x, 0.35, z), 0.36, 0.22, Color("242424"))
				wheel.rotation_degrees.z = 90
				car.add_child(wheel)
		add_child(car)
		interactables.append(car)

func _make_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 0.2, 8)
	player.set_script(PlayerScript)
	player.setup(self)
	add_child(player)

func _make_characters() -> void:
	var pi := _fruit_character("Piña", Vector3(4,0,-8), Color("f4c542"), true)
	pi.name = "PinaNPC"
	add_child(pi)
	interactables.append(pi)
	var gu := _fruit_character("Guayaba", Vector3(-10,0,5), Color("80c96c"), false)
	gu.name = "GuayabaNPC"
	add_child(gu)
	interactables.append(gu)
	var fr := _fruit_character("Fresa", Vector3(0,0,8), Color("f04455"), false)
	fr.name = "FresaLook"
	fr.visible = false
	add_child(fr)

func _make_coins() -> void:
	for p in [Vector3(-13,1,0), Vector3(14,1,-12), Vector3(22,1,16), Vector3(-25,1,-20), Vector3(6,1,25)]:
		var coin := _sphere("Coin", p, Vector3(0.45,0.45,0.16), Color("ffd83d"))
		coin.rotation_degrees.z = 15
		coin.set_meta("coin", true)
		add_child(coin)
		interactables.append(coin)

func _make_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 18)
	panel.custom_minimum_size = Vector2(390, 112)
	hud.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 4)
	panel.add_child(col)
	var title := Label.new()
	title.text = "FRUTOMANÍA  •  MUNDO ABIERTO"
	title.add_theme_font_size_override("font_size", 20)
	col.add_child(title)
	mission_label = Label.new()
	mission_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(mission_label)
	status_label = Label.new()
	col.add_child(status_label)
	var controls := ControlsScript.new()
	controls.name = "MobileControls"
	controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(controls)
	player.mobile_controls = controls

func _update_hud() -> void:
	if is_instance_valid(mission_label): mission_label.text = mission_texts[min(mission_index, mission_texts.size()-1)]
	if is_instance_valid(status_label): status_label.text = "Personaje: %s   |   Monedas: %d/3\nMover: joystick   Saltar: ↑   Acción: E" % [characters[character_index], coins]

func try_interact() -> void:
	if player.driving_vehicle != null:
		player.exit_vehicle()
		_set_message("Has salido del Fruta-móvil.")
		return
	var nearest: Node3D = null
	var nearest_d := 999.0
	for obj in interactables:
		if not is_instance_valid(obj) or not obj.visible: continue
		var d := player.global_position.distance_to(obj.global_position)
		if d < nearest_d:
			nearest_d = d
			nearest = obj
	if nearest and nearest_d < 3.4:
		if nearest.has_meta("coin"):
			coins += 1
			nearest.queue_free()
			interactables.erase(nearest)
			if coins >= 3 and mission_index == 0: mission_index = 1
			_update_hud()
		elif nearest.has_meta("drivable_car"):
			player.enter_vehicle(nearest)
			_set_message("¡Conduce! Joystick: dirección · ACCIÓN: salir")
		elif nearest.has_meta("house_enter"):
			player.global_position = Vector3(220, 0.2, 221.7)
			_set_message("Entraste a la casa. Busca la puerta para salir.")
		elif nearest.has_meta("house_exit"):
			player.global_position = Vector3(24, 0.2, 18.0)
			_set_message("Has salido de la casa.")
		elif nearest.name == "PinaNPC" and mission_index >= 1:
			mission_index = 2
			mission_done = true
			_update_hud()
		else:
			_set_message("%s: ¡Qué bueno verte! Busca monedas y completa misiones." % nearest.name.replace("NPC", ""))
	else:
		_set_message("Acércate a una puerta, un vehículo o un personaje y pulsa ACCIÓN.")

func _set_message(message: String) -> void:
	if is_instance_valid(status_label): status_label.text = message

func switch_character() -> void:
	character_index = (character_index + 1) % characters.size()
	player.set_character(character_index)
	_update_hud()

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.name = n
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9
	node.material_override = mat
	return node

func _sphere(n: String, pos: Vector3, scale_v: Vector3, color: Color) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.name = n
	var mesh := SphereMesh.new()
	mesh.radius = 0.6
	mesh.height = 1.2
	node.mesh = mesh
	node.position = pos
	node.scale = scale_v
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.55
	node.material_override = mat
	return node

func _cylinder(n: String, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.name = n
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	node.mesh = mesh
	node.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	node.material_override = mat
	return node

func _fruit_character(label: String, pos: Vector3, color: Color, pineapple: bool) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.name = label
	var body := _sphere("Fruit body", Vector3(0,1.15,0), Vector3(0.9,1.0,0.75), color)
	root.add_child(body)
	# friendly eyes on front (-Z)
	for x in [-0.24, 0.24]:
		var eye := _sphere("Eye", Vector3(x,1.48,-0.58), Vector3(0.13,0.16,0.08), Color.WHITE)
		root.add_child(eye)
		var pupil := _sphere("Pupil", Vector3(x,1.47,-0.65), Vector3(0.055,0.075,0.035), Color("20202b"))
		root.add_child(pupil)
	var smile := _box("Smile", Vector3(0,1.08,-0.59), Vector3(0.28,0.055,0.04), Color("6b2e2e"))
	root.add_child(smile)
	if pineapple:
		for i in range(5):
			var leaf := _sphere("Leaf", Vector3((i-2)*0.12,2.12+abs(i-2)*0.04,0), Vector3(0.16,0.42,0.12), Color("39a852"))
			leaf.rotation_degrees.z = float(i-2)*18
			root.add_child(leaf)
	else:
		var leaf := _sphere("Leaf", Vector3(0,2.0,0), Vector3(0.3,0.16,0.15), Color("2e9b50"))
		leaf.rotation_degrees.z = -25
		root.add_child(leaf)
	var leg_mat := Color("394052")
	for x in [-0.28,0.28]:
		var leg := _box("Leg", Vector3(x,0.35,0), Vector3(0.18,0.55,0.2), leg_mat)
		root.add_child(leg)
	var name_label := Label3D.new()
	name_label.text = label
	name_label.position = Vector3(0,2.55,0)
	name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_label.font_size = 32
	name_label.outline_size = 6
	root.add_child(name_label)
	return root
