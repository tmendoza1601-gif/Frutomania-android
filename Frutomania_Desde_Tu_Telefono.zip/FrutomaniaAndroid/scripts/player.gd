extends CharacterBody3D

var world: Node
var mobile_controls: Control
var speed := 7.0
var jump_velocity := 7.5
var gravity := 20.0
var camera_pivot: Node3D
var camera: Camera3D
var visual: Node3D
var fruit_colors := [Color("f04455"), Color("f4c542"), Color("80c96c")]
var fruit_names := ["Fresa", "Piña", "Guayaba"]
var joystick_axis := Vector2.ZERO
var driving_vehicle: Node3D = null
var vehicle_speed := 0.0

func setup(world_node: Node) -> void:
	world = world_node
	_build_player()

func _ready() -> void:
	if visual == null: _build_player()

func _build_player() -> void:
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.48
	shape.height = 2.1
	collision.shape = shape
	collision.position.y = 1.0
	add_child(collision)
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	_build_visual(0)
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0,2.4,0)
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0,2.0,6.8)
	camera.rotation_degrees.x = -12
	camera.current = true
	camera.fov = 72
	camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
	if not is_inside_tree(): return
	if driving_vehicle != null and is_instance_valid(driving_vehicle):
		_process_vehicle(delta)
		return
	var input_vec := Vector2.ZERO
	input_vec.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_vec.y = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
	if mobile_controls and mobile_controls.has_method("get_axis"):
		var touch_axis: Vector2 = mobile_controls.get_axis()
		if touch_axis.length() > 0.1: input_vec = touch_axis
	input_vec = input_vec.limit_length(1.0)
	var cam_forward := -camera.global_transform.basis.z
	cam_forward.y = 0
	cam_forward = cam_forward.normalized()
	var cam_right := camera.global_transform.basis.x
	cam_right.y = 0
	cam_right = cam_right.normalized()
	var direction := (cam_right * input_vec.x + cam_forward * -input_vec.y).normalized()
	if direction.length() > 0.05:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		visual.rotation.y = lerp_angle(visual.rotation.y, atan2(direction.x, direction.z), delta * 10.0)
	else:
		velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
		velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
	if not is_on_floor(): velocity.y -= gravity * delta
	else:
		if Input.is_action_just_pressed("jump") or (mobile_controls and mobile_controls.consume_jump()): velocity.y = jump_velocity
	if Input.is_action_just_pressed("interact") or (mobile_controls and mobile_controls.consume_action()):
		if world and world.has_method("try_interact"): world.try_interact()
	if Input.is_action_just_pressed("switch_character") or (mobile_controls and mobile_controls.consume_switch()):
		if world and world.has_method("switch_character"): world.switch_character()
	move_and_slide()
	# Keep the camera aimed toward the character while smoothing its position.
	if camera_pivot:
		camera_pivot.global_position = camera_pivot.global_position.lerp(global_position + Vector3(0,2.4,0), delta * 8.0)

func enter_vehicle(vehicle: Node3D) -> void:
	if not is_instance_valid(vehicle): return
	driving_vehicle = vehicle
	if is_instance_valid(visual): visual.visible = false
	for child in get_children():
		if child is CollisionShape3D: child.disabled = true
	velocity = Vector3.ZERO
	global_position = vehicle.global_position

func exit_vehicle() -> void:
	if driving_vehicle == null: return
	var vehicle := driving_vehicle
	driving_vehicle = null
	if is_instance_valid(visual): visual.visible = true
	for child in get_children():
		if child is CollisionShape3D: child.disabled = false
	global_position = vehicle.global_position + vehicle.global_transform.basis.x * 1.8 + Vector3.UP * 0.1
	velocity = Vector3.ZERO

func _process_vehicle(delta: float) -> void:
	var input_vec := Vector2.ZERO
	input_vec.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_vec.y = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
	if mobile_controls and mobile_controls.has_method("get_axis"):
		var touch_axis: Vector2 = mobile_controls.get_axis()
		if touch_axis.length() > 0.1: input_vec = touch_axis
	input_vec = input_vec.limit_length(1.0)
	var throttle := -input_vec.y
	vehicle_speed = move_toward(vehicle_speed, throttle * 13.0, 10.0 * delta)
	if abs(vehicle_speed) > 0.15:
		driving_vehicle.rotate_y(-input_vec.x * delta * 1.65 * sign(vehicle_speed))
		var forward := -driving_vehicle.global_transform.basis.z
		driving_vehicle.global_position += forward * vehicle_speed * delta
		driving_vehicle.global_position.y = 0.15
	global_position = driving_vehicle.global_position
	if camera_pivot:
		camera_pivot.global_position = camera_pivot.global_position.lerp(global_position + Vector3(0,3.0,0), delta * 5.0)
	if mobile_controls and mobile_controls.consume_action():
		if world and world.has_method("try_interact"): world.try_interact()

func set_character(index: int) -> void:
	_build_visual(index)

func _build_visual(index: int) -> void:
	if not is_instance_valid(visual): return
	for child in visual.get_children(): child.queue_free()
	var body := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.58
	mesh.height = 1.25
	body.mesh = mesh
	body.position.y = 1.15
	body.scale = Vector3(1.0,1.18,0.86)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = fruit_colors[index]
	mat.roughness = 0.5
	body.material_override = mat
	visual.add_child(body)
	# Leaf crown
	for i in range(5 if index == 1 else 3):
		var leaf := MeshInstance3D.new()
		var lm := SphereMesh.new()
		lm.radius = 0.16
		lm.height = 0.65
		leaf.mesh = lm
		leaf.position = Vector3((i-2)*0.12,2.0 + abs(i-2)*0.035,0)
		leaf.scale = Vector3(0.65,1.0,0.5)
		leaf.rotation_degrees.z = float(i-2)*18
		var leafmat := StandardMaterial3D.new()
		leafmat.albedo_color = Color("39a852")
		leaf.material_override = leafmat
		visual.add_child(leaf)
	# eyes and pupils face -Z
	for x in [-0.22,0.22]:
		var eye := _ellipsoid(Vector3(x,1.42,-0.47), Vector3(0.13,0.17,0.08), Color.WHITE)
		visual.add_child(eye)
		var pupil := _ellipsoid(Vector3(x,1.42,-0.54), Vector3(0.055,0.08,0.035), Color("20202b"))
		visual.add_child(pupil)
	var mouth := MeshInstance3D.new()
	var mm := BoxMesh.new()
	mm.size = Vector3(0.25,0.045,0.04)
	mouth.mesh = mm
	mouth.position = Vector3(0,1.08,-0.5)
	var mouthmat := StandardMaterial3D.new()
	mouthmat.albedo_color = Color("6b2e2e")
	mouth.material_override = mouthmat
	visual.add_child(mouth)
	for x in [-0.28,0.28]:
		var leg := MeshInstance3D.new()
		var lm := BoxMesh.new()
		lm.size = Vector3(0.18,0.48,0.2)
		leg.mesh = lm
		leg.position = Vector3(x,0.3,0)
		var legmat := StandardMaterial3D.new()
		legmat.albedo_color = Color("394052")
		leg.material_override = legmat
		visual.add_child(leg)

func _ellipsoid(pos: Vector3, scale_v: Vector3, color: Color) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	var m := SphereMesh.new()
	m.radius = 0.6
	m.height = 1.2
	n.mesh = m
	n.position = pos
	n.scale = scale_v
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	n.material_override = mat
	return n
