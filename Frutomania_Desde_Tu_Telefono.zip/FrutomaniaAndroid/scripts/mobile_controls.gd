extends Control

var axis := Vector2.ZERO
var stick_touch := -1
var stick_center := Vector2(120, 0)
var stick_origin := Vector2.ZERO
var stick_current := Vector2.ZERO
var jump_requested := false
var action_requested := false
var switch_requested := false
var button_rects := {}

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_process_input(true)
	queue_redraw()

func _draw() -> void:
	var size := get_viewport_rect().size
	# Left virtual joystick
	var center := Vector2(112, size.y - 125)
	draw_circle(center, 76, Color(0.05,0.07,0.1,0.35))
	draw_arc(center, 76, 0, TAU, 48, Color(1,1,1,0.55), 3.0)
	var knob := center + axis * 42.0
	draw_circle(knob, 31, Color(0.88,0.92,1,0.55))
	draw_arc(knob, 31, 0, TAU, 32, Color(1,1,1,0.8), 2.0)
	# Right buttons
	button_rects = {
		"jump": Rect2(size.x-108,size.y-235,78,78),
		"action": Rect2(size.x-205,size.y-132,82,82),
		"switch": Rect2(size.x-105,size.y-132,82,82)
	}
	_draw_button(button_rects.jump, "↑", Color(0.24,0.62,0.92,0.62))
	_draw_button(button_rects.action, "E\nACCIÓN", Color(0.25,0.72,0.45,0.62))
	_draw_button(button_rects.switch, "CAMBIAR", Color(0.72,0.4,0.82,0.62))

func _draw_button(rect: Rect2, text: String, color: Color) -> void:
	draw_circle(rect.position + rect.size/2, rect.size.x/2, color)
	draw_arc(rect.position + rect.size/2, rect.size.x/2, 0, TAU, 36, Color(1,1,1,0.8), 2.0)
	var lines := text.split("\n")
	var font := ThemeDB.fallback_font
	var y := rect.position.y + rect.size.y/2 - (lines.size()-1)*8
	for line in lines:
		var tw := font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x
		draw_string(font, Vector2(rect.position.x + (rect.size.x-tw)/2, y+5), line, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE)
		y += 17

func _gui_input(event: InputEvent) -> void:
	var size := get_viewport_rect().size
	var center := Vector2(112, size.y - 125)
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.distance_to(center) < 100 and stick_touch == -1:
				stick_touch = event.index
				stick_origin = center
				_update_axis(event.position)
			else:
				for key in button_rects:
					if button_rects[key].has_point(event.position):
						if key == "jump": jump_requested = true
						elif key == "action": action_requested = true
						elif key == "switch": switch_requested = true
						accept_event()
		else:
				if event.index == stick_touch:
					stick_touch = -1
					axis = Vector2.ZERO
					queue_redraw()
	elif event is InputEventScreenDrag and event.index == stick_touch:
		_update_axis(event.position)

func _update_axis(pos: Vector2) -> void:
	var center := Vector2(112, get_viewport_rect().size.y - 125)
	axis = ((pos-center)/52.0).limit_length(1.0)
	queue_redraw()

func get_axis() -> Vector2:
	return axis

func consume_jump() -> bool:
	var v := jump_requested
	jump_requested = false
	return v

func consume_action() -> bool:
	var v := action_requested
	action_requested = false
	return v

func consume_switch() -> bool:
	var v := switch_requested
	switch_requested = false
	return v
